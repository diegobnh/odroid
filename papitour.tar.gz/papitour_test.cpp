#include <cstdio>
#include <papi.h>
#include <thread>
#include <mutex>
#include <iterator>

struct event_table_item_t
{
    const char* name;
    int event_code;
};

static event_table_item_t event_table[] = {
    { "perf::PERF_COUNT_HW_INSTRUCTIONS", -1 },
    { "perf::PERF_COUNT_HW_CACHE_MISSES", -1 },
    { "perf::PERF_COUNT_HW_BRANCH_MISSES", -1 },
};

static std::mutex papi_mutex;

int main()
{
    if(PAPI_library_init(PAPI_VER_CURRENT) != PAPI_VER_CURRENT)
    {
        fprintf(stderr, "PAPI library mismatch\n");
        return 1;
    }

    if(PAPI_thread_init(pthread_self) != PAPI_OK)
    {
        fprintf(stderr, "PAPI_thread_init failed\n");
        return 1;
    }

    for(int i = 0; i < std::size(event_table); ++i)
    {
        if(PAPI_event_name_to_code(event_table[i].name, &event_table[i].event_code) != PAPI_OK)
        {
            fprintf(stderr, "cannot find %s\n", event_table[i].name);
            return 1;
        }

        if(PAPI_query_event(event_table[i].event_code) != PAPI_OK)
        {
            fprintf(stderr, "cannot query %s\n", event_table[i].name);
            return 1;
        }
    }

    std::thread tvec[10];
    for(int thread_id = 0; thread_id < std::size(tvec); ++thread_id)
    {
        tvec[thread_id] = std::thread([thread_id] {

            int thread_eventset = PAPI_NULL;
            long long values[std::size(event_table)];

            // this is the portion of the library that is not thread safe
            papi_mutex.lock();
            if(PAPI_create_eventset(&thread_eventset) != PAPI_OK)
            {
                papi_mutex.unlock();
                fprintf(stderr, "failed to PAPI_create_eventset at thread %d\n", thread_id);
                return;
            }
            papi_mutex.unlock();

            for(int i = 0; i < std::size(event_table); ++i)
            {
                if(PAPI_add_event(thread_eventset, event_table[i].event_code) != PAPI_OK)
                {
                    fprintf(stderr, "failed to PAPI_add_event %s at thread %d\n", event_table[i].name, thread_id);
                    return;
                }
            }

            if(PAPI_start(thread_eventset) != PAPI_OK)
            {
                fprintf(stderr, "failed to PAPI_start at thread %d\n", thread_id);
                return;
            }

            for(int i = 1; i < (1 << thread_id); ++i)
            {
                volatile int sum = 0; // avoid optimization
                for(int j = 0; j < 100000; ++j)
                    sum += j;
            }

            if(PAPI_stop(thread_eventset, values) != PAPI_OK)
            {
                fprintf(stderr, "failed to PAPI_stop at thread %d\n", thread_id);
                return;
            }

            if(PAPI_cleanup_eventset(thread_eventset) != PAPI_OK)
            {
                fprintf(stderr, "failed to PAPI_cleanup_eventset at thread %d\n", thread_id);
                return;
            }

            if(PAPI_destroy_eventset(&thread_eventset) != PAPI_OK)
            {
                fprintf(stderr, "failed to PAPI_destroy_eventset at thread %d\n", thread_id);
                return;
            }

            if(PAPI_unregister_thread() != PAPI_OK)
            {
                fprintf(stderr, "failed to PAPI_unregister_thread at thread %d\n", thread_id);
                return;
            }

            for(int i = 0; i < std::size(event_table); ++i)
            {
                fprintf(stdout, "thread %d counted %llu %s\n", thread_id, values[i], event_table[i].name);
            }
        });
    }

    for(int i = 0; i < std::size(tvec); ++i)
        tvec[i].join();
}
