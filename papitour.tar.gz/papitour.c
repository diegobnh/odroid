#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include <papi.h>
#include <unistd.h>
#include <sys/sysinfo.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <linux/perf_event.h>
#include <asm/unistd.h>

// NOTE: This implementation of PAPI is not thread-safe!
// This is to be used only in OMPP which acquires a lock before performing PAPI operations.

#define MAX_EVENT_SET 1000
#define MAX_PROCESSORS 8
#define MAX_EVENT_IN_SET 4

#define INVALID_EVENT_CODE (-1)

#define EVENTSET_FLAG_RUNNING (1 << 0)

#if 0
#define DEBUG(fmt, ...) ((void)fprintf(stderr, fmt "\n", __VA_ARGS__))
#else
#define DEBUG(fmt, ...) ((void)0)
#endif

typedef struct
{
    int event_code;
    const char* name;
    uint32_t perf_type;
    uint64_t perf_config;
} perfmap_item_t;

typedef struct
{
    int fd;
    uint64_t id;
    uint64_t prev_value;
} perfevt_t;

typedef struct
{
    int flags;
    int event_code[MAX_EVENT_IN_SET];
    perfevt_t events[MAX_PROCESSORS][MAX_EVENT_IN_SET];

} evtset_t;

static bool has_initialized = false;
static int num_cpu = 0;
static evtset_t* event_set_pool[MAX_EVENT_SET];

static const perfmap_item_t perfmap[] = {
    { 1, "perf::PERF_COUNT_HW_CPU_CYCLES", PERF_TYPE_HARDWARE, PERF_COUNT_HW_CPU_CYCLES },
    { 2, "perf::PERF_COUNT_HW_INSTRUCTIONS", PERF_TYPE_HARDWARE, PERF_COUNT_HW_INSTRUCTIONS },
    { 3, "perf::PERF_COUNT_HW_CACHE_REFERENCES", PERF_TYPE_HARDWARE, PERF_COUNT_HW_CACHE_REFERENCES },
    { 4, "perf::PERF_COUNT_HW_CACHE_MISSES", PERF_TYPE_HARDWARE, PERF_COUNT_HW_CACHE_MISSES },
    { 5, "perf::PERF_COUNT_HW_BRANCH_INSTRUCTIONS", PERF_TYPE_HARDWARE, PERF_COUNT_HW_BRANCH_INSTRUCTIONS },
    { 6, "perf::PERF_COUNT_HW_BRANCH_MISSES", PERF_TYPE_HARDWARE, PERF_COUNT_HW_BRANCH_MISSES },
    // add more if needed
    { INVALID_EVENT_CODE, NULL, 0, 0 },
};


//
// Helper Functions
//

static long perf_event_open(struct perf_event_attr *hw_event, pid_t pid,
                            int cpu, int group_fd, unsigned long flags);

static int PAPI_read_internal(int EventSet, long long *values);

//
// PAPI API functions
// 

int PAPI_library_init(int version)
{
    DEBUG("PAPI_library_init called", 0);

    if(version != PAPI_VER_CURRENT)
        return PAPI_EINVAL;

    if(has_initialized)
        return PAPI_VER_CURRENT;

    num_cpu = get_nprocs_conf();
    if(num_cpu > MAX_PROCESSORS)
    {
        DEBUG("ERROR: too many CPUs, please increase MAX_PROCESSORS macro constant.", 0);
        return PAPI_EBUG;
    }

    for(const perfmap_item_t* p = perfmap; p->name; ++p)
    {
        if(p->event_code == INVALID_EVENT_CODE)
        {
            DEBUG("ERROR: event in perfmap collides with INVALID_EVENT_CODE!", 0);
            return PAPI_EBUG;
        }
    }

    for(int i = 0; i < MAX_EVENT_SET; ++i)
        event_set_pool[i] = NULL;

    has_initialized = true;
    return PAPI_VER_CURRENT;
}

int PAPI_thread_init(unsigned long int (*id_fn) (void))
{
    // There is no need to implement anything here.
    return PAPI_OK;
}

int PAPI_unregister_thread(void)
{
    // There is no need to implement anything here.
    return PAPI_OK;
}

int PAPI_num_components(void)
{
    // There is no need to implement anything here.
    return 1; // perf_event component
}

int PAPI_set_opt(int option, PAPI_option_t* ptr)
{
    // There is no need to implement anything here, but keep ENOIMPL!
    return PAPI_ENOIMPL;
}

int PAPI_event_name_to_code(const char *in, int *out)
{
    DEBUG("PAPI_event_name_to_code(%s) called", in, 0);
    for(const perfmap_item_t* p = perfmap; p->name; ++p)
    {
        if(!strcmp(in, p->name))
        {
            *out = p->event_code;
            return PAPI_OK;
        }
    }
    return PAPI_ENOTPRESET;
}

int PAPI_query_event(int EventCode)
{
    // Not going to implement this function. We assume everything in the
    // perfmap table is available in the architecture.
    return PAPI_OK;
}

int PAPI_create_eventset(int *EventSet)
{
    DEBUG("PAPI_create_eventset called", 0);

    if(EventSet == NULL || *EventSet != PAPI_NULL)
        return PAPI_EINVAL;

    for(int i = 1; i < MAX_EVENT_SET; ++i)
    {
        if(event_set_pool[i] == NULL)
        {
            assert(i != 0); // Never allocate the eventset 0.
            DEBUG("allocating eventset %d", i, 0);

            event_set_pool[i] = malloc(sizeof(evtset_t));

            event_set_pool[i]->flags = 0;

            for(int j = 0; j < MAX_EVENT_IN_SET; ++j)
                event_set_pool[i]->event_code[j] = INVALID_EVENT_CODE;

            for(int cpu = 0; cpu < MAX_PROCESSORS; ++cpu)
            {
                for(int cid = 0; cid < MAX_EVENT_IN_SET; ++cid)
                {
                    event_set_pool[i]->events[cpu][cid].fd = -1;
                    event_set_pool[i]->events[cpu][cid].id = -1;
                    event_set_pool[i]->events[cpu][cid].prev_value = 0;
                }
            }

            *EventSet = i;
            return PAPI_OK;
        }
    }

    return PAPI_ENOMEM;
}

int PAPI_destroy_eventset(int *EventSet)
{
    DEBUG("PAPI_destroy_eventset(%d) called", EventSet? *EventSet : 0, 0);

    if(EventSet == NULL || *EventSet <= 0 || *EventSet >= MAX_EVENT_SET)
        return PAPI_EINVAL;

    if(event_set_pool[*EventSet] == NULL)
        return PAPI_ENOEVST;

    if(event_set_pool[*EventSet]->flags & EVENTSET_FLAG_RUNNING)
        return PAPI_EISRUN;

    for(int cpu = 0; cpu < MAX_PROCESSORS; ++cpu)
    {
        for(int cid = 0; cid < MAX_EVENT_IN_SET; ++cid)
        {
            if(event_set_pool[*EventSet]->events[cpu][cid].fd != -1)
            {
                DEBUG("attempting to destroy a non-empty eventset", 0);
                return PAPI_EINVAL;
            }
        }
    }

    free(event_set_pool[*EventSet]);
    event_set_pool[*EventSet] = NULL;
    *EventSet = 0;

    return PAPI_OK;
}

int PAPI_add_event(int EventSet, int EventCode)
{
    DEBUG("PAPI_add_event(%d, %d) called", EventSet, EventCode, 0);

    if(EventSet <= 0 || EventSet >= MAX_EVENT_SET)
        return PAPI_EINVAL;

    if(event_set_pool[EventSet] == NULL)
        return PAPI_ENOEVST;

    if(event_set_pool[EventSet]->flags & EVENTSET_FLAG_RUNNING)
        return PAPI_EISRUN;

    if(EventCode == INVALID_EVENT_CODE)
        return PAPI_EINVAL;

    const perfmap_item_t* perfitem = perfmap;
    for(; perfitem->event_code != EventCode; ++perfitem)
    {
        // Reached the end of the list but EventCode not found.
        if(perfitem->name == NULL)
            return PAPI_EINVAL;
    }
    
    evtset_t* evtset = event_set_pool[EventSet];

    int cid;
    for(cid = 0; cid < MAX_EVENT_IN_SET; ++cid)
    {
        if(evtset->events[0][cid].fd == -1)
            break;
    }

    if(cid == MAX_EVENT_IN_SET)
    {
        DEBUG("too many events in event set", 0);
        return PAPI_ECNFLCT;
    }

    for(int cpu = 0; cpu < num_cpu; ++cpu)
    {
        assert(evtset->events[cpu][cid].fd == -1);

        int group_fd = (cid == 0? -1 : evtset->events[cpu][0].fd);

        struct perf_event_attr pe;
        memset(&pe, 0, sizeof(pe));
        pe.size = sizeof(pe);
        pe.type = perfitem->perf_type;
        pe.config = perfitem->perf_config;
        pe.exclude_hv = 1;
        pe.exclude_kernel = 1;
        pe.disabled = 1;
        pe.read_format = PERF_FORMAT_ID | PERF_FORMAT_GROUP;

        int fd = perf_event_open(&pe, 0, cpu, group_fd, 0);
        if(fd == -1)
        {
            // We could recover and return PAPI_ESYS, but ehh too lazy.
            perror("failed to perf_event_open");
            abort();
        }

        evtset->events[cpu][cid].fd = fd;
        ioctl(fd, PERF_EVENT_IOC_ID, &evtset->events[cpu][cid].id);
        ioctl(fd, PERF_EVENT_IOC_RESET, 0);
        evtset->events[cpu][cid].prev_value = 0;
    }

    return PAPI_OK;
}

int PAPI_cleanup_eventset(int EventSet)
{
    DEBUG("PAPI_cleanup_eventset(%d) called", EventSet, 0);

    if(EventSet <= 0 || EventSet >= MAX_EVENT_SET)
        return PAPI_EINVAL;

    if(event_set_pool[EventSet] == NULL)
        return PAPI_ENOEVST;

    if(event_set_pool[EventSet]->flags & EVENTSET_FLAG_RUNNING)
        return PAPI_EISRUN;

    evtset_t* evtset = event_set_pool[EventSet];

    for(int cpu = 0; cpu < MAX_PROCESSORS; ++cpu)
    {
        for(int cid = 0; cid < MAX_EVENT_IN_SET; ++cid)
        {
            int fd = evtset->events[cpu][cid].fd;
            if(fd != -1)
            {
                close(fd);
                evtset->events[cpu][cid].fd = -1;
                evtset->events[cpu][cid].id = -1;
                evtset->events[cpu][cid].prev_value = 0;
            }
        }
    }

    return PAPI_OK;
}

int PAPI_start(int EventSet)
{
    DEBUG("PAPI_start(%d) called", EventSet, 0);

    if(EventSet <= 0 || EventSet >= MAX_EVENT_SET)
        return PAPI_EINVAL;

    if(event_set_pool[EventSet] == NULL)
        return PAPI_ENOEVST;

    if(event_set_pool[EventSet]->flags & EVENTSET_FLAG_RUNNING)
        return PAPI_EISRUN;

    for(int cpu = 0; cpu < num_cpu; ++cpu)
    {
        int leader_fd = event_set_pool[EventSet]->events[cpu][0].fd;
        if(leader_fd != -1)
            ioctl(leader_fd, PERF_EVENT_IOC_ENABLE, PERF_IOC_FLAG_GROUP);
    }

    event_set_pool[EventSet]->flags |= EVENTSET_FLAG_RUNNING;
    return PAPI_OK;
}

int PAPI_stop(int EventSet, long long *values)
{
    DEBUG("PAPI_stop(%d) called", EventSet, 0);

    if(EventSet <= 0 || EventSet >= MAX_EVENT_SET)
        return PAPI_EINVAL;

    if(event_set_pool[EventSet] == NULL)
        return PAPI_ENOEVST;

    if((event_set_pool[EventSet]->flags & EVENTSET_FLAG_RUNNING) == 0)
        return PAPI_ENOTRUN;

    if(values == NULL)
        return PAPI_EINVAL;

    for(int cpu = 0; cpu < num_cpu; ++cpu)
    {
        int leader_fd = event_set_pool[EventSet]->events[cpu][0].fd;
        if(leader_fd != -1)
            ioctl(leader_fd, PERF_EVENT_IOC_DISABLE, PERF_IOC_FLAG_GROUP);
    }

    event_set_pool[EventSet]->flags &= ~EVENTSET_FLAG_RUNNING;
    return PAPI_read_internal(EventSet, values);
}

int PAPI_read(int EventSet, long long *values)
{
    DEBUG("PAPI_read(%d) called", EventSet, 0);

    if(EventSet <= 0 || EventSet >= MAX_EVENT_SET)
        return PAPI_EINVAL;

    if(event_set_pool[EventSet] == NULL)
        return PAPI_ENOEVST;

    if(values == NULL)
        return PAPI_EINVAL;

    return PAPI_read_internal(EventSet, values);
}

static int PAPI_read_internal(int EventSet, long long *values)
{
    // no need to check parameters, this is an internal function.

    evtset_t* evtset = event_set_pool[EventSet];

    struct
    {
        uint64_t nr;    /* The number of events */
        struct {
            uint64_t value; /* The value of the event */
            uint64_t id;    /* if PERF_FORMAT_ID */
        } values[MAX_EVENT_IN_SET];
    } data;

    int num_counters = 0;
    for(int cid = 0; cid < MAX_EVENT_IN_SET; ++cid)
    {
        if(evtset->events[0][cid].fd == -1)
            break;
        ++num_counters;
    }

    for(int cid = 0; cid < num_counters; ++cid)
        values[cid] = 0;

    for(int cpu = 0; cpu < num_cpu; ++cpu)
    {
        int leader_fd = evtset->events[cpu][0].fd;

        if(leader_fd == -1)
            continue;

        if(read(leader_fd, &data, sizeof(data)) == -1)
            return PAPI_ESYS;

        for(uint64_t s = 0; s < data.nr; ++s)
        {
            for(int cid = 0; cid < num_counters; ++cid)
            {
                if(data.values[s].id == evtset->events[cpu][cid].id)
                {
                    values[cid] += data.values[s].value;
                }
            }
        }
    }

    return PAPI_OK;
}

static long perf_event_open(struct perf_event_attr *hw_event, pid_t pid,
                            int cpu, int group_fd, unsigned long flags)
{
    int ret;
    ret = syscall(__NR_perf_event_open, hw_event, pid, cpu, group_fd, flags);
    return ret;
}

