#ifndef PMC_GET_ROW_H_
#define PMC_GET_ROW_H_
int is_cpu_online(int cpu_num) ;
int get_num_counters_from_file(int cpu_num);
void pmc_get_row();
#endif
